<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Insert Sample Data</title>
  <link rel="stylesheet" href="css\style.css">
</head>
<body id="entry-page">
  <nav class="flexColumn">
  <div id="logo">
    <img src="imgs/PHP-MySQL-Logo_W_Group4.png" alt="Website Logo">
  </div>
  <div class="navTab">
    <a href="index.php">Home</a>
  </div>
  <div class="navTab">
    <a href="phpForm.php">PHP Form Tutorial</a>
  </div>
  <div class="navTab">
    <a href="phpMySQL.php">PHP MySQL Tutorials</a>
  </div>
  <div class="navTab subTab">
    <a href="phpFormDB.php">Inserting Data into a Database Using a Form</a>
  </div>
  <div class="navTab subTab">
    <a href="updatingDB.php">Updating Data in a Database Using a Form</a>
  </div>
  <div class="navTab subTab">
    <a href="returnedQuery.php" id="active">Displaying Data Returned via a Query in a Database</a>
  </div>
  <div class="navTab">
    <a href="dataVisualization.php">Data Visualization</a>
  </div>
</nav>
<header>
  <h1>Sample Data Entered</h1>
</header>
<main class="flexColumn" id="sample-dataPage">
  <h2>Sample Data</h2>
  <p>10 rows have been inserted into the database</p>
    <?php
      $servername = "localhost";
      $username = "myusername";
      $password = "myPassword";
      $dbname = "surveydb";

      // Create connection
      $conn = mysqli_connect($servername, $username, $password, $dbname);

      // Check connection
      if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
      }

      // Multiple INSERT statements
      //1
      $sql = "INSERT INTO survey_responses (name, comfort_mysql, comfort_php, comfort_html, favorite_beverage,
          skill_time, skill_focus, skill_notes, skill_collab, skill_problem, skill_stress)
        VALUES ('Alice Johnson', 4, 3, 5, 'Coffee', 8, 7, 9, 8, 6, 7);";
      //2
      $sql .= "INSERT INTO survey_responses (name, comfort_mysql, comfort_php, comfort_html, favorite_beverage,
          skill_time, skill_focus, skill_notes, skill_collab, skill_problem, skill_stress)
        VALUES ('Bob Smith', 2, 2, 3, 'Tea', 5, 6, 4, 7, 5, 6);";
      //3
      $sql .= "INSERT INTO survey_responses (name, comfort_mysql, comfort_php, comfort_html, favorite_beverage,
          skill_time, skill_focus, skill_notes, skill_collab, skill_problem, skill_stress)
        VALUES ('Julia Red', 5, 5, 5, 'Energy Drink', 9, 9, 9, 9, 9, 9);";
      //4
      $sql .= "INSERT INTO survey_responses (name, comfort_mysql, comfort_php, comfort_html, favorite_beverage,
          skill_time, skill_focus, skill_notes, skill_collab, skill_problem, skill_stress)
        VALUES ('Charlie Green', 5, 4, 4, 'Water', 9, 8, 9, 9, 8, 9);";
      //5
      $sql .= "INSERT INTO survey_responses (name, comfort_mysql, comfort_php, comfort_html, favorite_beverage,
          skill_time, skill_focus, skill_notes, skill_collab, skill_problem, skill_stress)
        VALUES ('Diana King', 3, 5, 5, 'Soda', 7, 6, 7, 8, 6, 7);";
      //6
      $sql .= "INSERT INTO survey_responses (name, comfort_mysql, comfort_php, comfort_html, favorite_beverage,
          skill_time, skill_focus, skill_notes, skill_collab, skill_problem, skill_stress)
        VALUES ('Ethan Brown', 4, 4, 4, 'Energy Drink', 6, 5, 7, 6, 5, 6);";
      //7
      $sql .=  "INSERT INTO survey_responses (name, comfort_mysql, comfort_php, comfort_html, favorite_beverage,
          skill_time, skill_focus, skill_notes, skill_collab, skill_problem, skill_stress)
        VALUES ('Fiona White', 5, 3, 4, 'Tea', 9, 9, 8, 9, 9, 8);";
      //8
      $sql .= "INSERT INTO survey_responses (name, comfort_mysql, comfort_php, comfort_html, favorite_beverage,
          skill_time, skill_focus, skill_notes, skill_collab, skill_problem, skill_stress)
        VALUES ('George Black', 2, 3, 2, 'Water', 4, 3, 5, 6, 4, 5);";
      //9
      $sql .= "INSERT INTO survey_responses (name, comfort_mysql, comfort_php, comfort_html, favorite_beverage,
          skill_time, skill_focus, skill_notes, skill_collab, skill_problem, skill_stress)
        VALUES ('Hannah Blue', 3, 4, 5, 'Coffee', 7, 7, 8, 7, 6, 8);";
      //10
      $sql .= "INSERT INTO survey_responses (name, comfort_mysql, comfort_php, comfort_html, favorite_beverage,
          skill_time, skill_focus, skill_notes, skill_collab, skill_problem, skill_stress)
        VALUES ('Ian Gray', 1, 2, 2, 'Soda', 3, 4, 3, 4, 3, 4)";

      if ($conn->multi_query($sql) === TRUE) {
    echo "New records created successfully";
    } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
  ?>
  <div id="return">
    <a href="returnedQuery.php">Return to previous page</a>
  </div>
</main>
<footer>
  <p>Group 4: Madeline Lucas, Dillon Barnhardt, Gerome Vergara</p>
  <p>Dr. John Gerdes</p>
  <p><a href="#top">To Top</a></p>
</footer>
</body>
</html>