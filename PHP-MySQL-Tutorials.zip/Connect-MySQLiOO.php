<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Connect - MySQLi Object Oriented</title>

  <link rel="stylesheet" href="css\style.css">
</head>
<body id="W3Schools-page">
  <nav class="flexColumn">
    <div id="logo">
        <img src="imgs/PHP-MySQL-Logo_W_Group4.png" alt="Website Logo">
    </div>
    <div class="navTab">
      <a href="index.php">Home</a>
    </div>
    <div class="navTab">
      <a href="phpForm.php">PHP Form Tutorial</a>
    </div>
    <div class="navTab">
      <a href="phpMySQL.php" id="active">PHP MySQL Tutorials</a>
    </div>
    <div class="navTab subTab">
      <a href="phpFormDB.php">Inserting Data into a Database Using a Form</a>
    </div>
    <div class="navTab subTab">
      <a href="updatingDB.php">Updating Data in a Database Using a Form</a>
    </div>
    <div class="navTab subTab">
      <a href="returnedQuery.php">Displaying Data Returned via a Query in a Database</a>
    </div>
    <div class="navTab">
      <a href="dataVisualization.php">Data Visualization</a>
    </div>
  </nav>

  <header>
    <h1>
      Connect - MySQLi Object Oriented
    </h1>
      <a href="https://www.w3schools.com/php/php_mysql_connect.asp" class="headerLink">W3Schools Link</a>
  </header>
  <main class="W3Schools-main">
    <h2>Step 1: Understanding This Page</h2>
    <p>This page tests whether your PHP setup can successfully connect to a MySQL database using the MySQLi <strong>object-oriented</strong> method.</p>

    <h2>Step 2: PHP Output</h2>
    <p>Below is the result of the PHP connection test:</p>
    <p>
      <?php
        $servername = "localhost";
        $username = "myusername";
        $password = "myPassword";

        // Create connection (object-oriented)
        $conn = new mysqli($servername, $username, $password);

        // Check connection
        if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
        }
        echo "Connected successfully";
      ?>
    </p>

    <h2>Step 3: How the Code Works</h2>
    <p>The PHP code used on this page looks like this:</p>
    <pre>
    &lt;?php
    $servername = "localhost";
    $username = "myusername";
    $password = "myPassword";

    // Create connection (object-oriented)
    $conn = new mysqli($servername, $username, $password);

    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }
    echo "Connected successfully";
    ?&gt;
    </pre>
    <p>This code connects PHP to your MySQL server using the object-oriented approach. 
    If the connection is successful, it displays <strong>"Connected successfully"</strong>; otherwise, it shows an error message.</p>

    <h2>Return to the Menu</h2>
    <p>Once you’ve confirmed the connection works, you can return to your main site menu below.</p>
    <a href="phpMySQL.php">Return to Menu</a>
  </main>
  <footer>
    <p>Group 4: Madeline Lucas, Dillon Barnhardt, Gerome Vergara</p>
    <p>Dr. John Gerdes</p>
    <p><a href="#top">To Top</a></p>
  </footer>
</body>
</html>