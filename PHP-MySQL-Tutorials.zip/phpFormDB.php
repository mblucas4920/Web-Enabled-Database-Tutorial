<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Lesson: Inserting Data Into a Database Using a Form</title>
        <link rel="stylesheet" href="css\style.css">
    </head>
    <body id="phpFormDB-page" class="lesson-page">
        <nav class="flexColumn">
            <div id="logo">
                <img src="imgs/PHP-MySQL-Logo_W_Group4.png" alt="Website Logo">
            </div>
            <div class="navTab">
                <a href="index.php">Home</a>
            </div>
            <div class="navTab">
                <a href="phpForm.php">PHP Form Tutorial</a>
            </div>
            <div class="navTab">
                <a href="phpMySQL.php">PHP MySQL Tutorials</a>
            </div>
            <div class="navTab subTab">
                <a href="phpFormDB.php" id="active">Inserting Data into a Database Using a Form</a>
            </div>
            <div class="navTab subTab">
                <a href="updatingDB.php">Updating Data in a Database Using a Form</a>
            </div>
            <div class="navTab subTab">
                <a href="returnedQuery.php">Displaying Data Returned via a Query in a Database</a>
            </div>
            <div class="navTab">
                <a href="dataVisualization.php">Data Visualization</a>
            </div>
        </nav>
        <header>
            <h1>Lesson: Inserting Data Into a Database Using a Form</h1>
        </header>
        <main class="flexColumn">
            <div class="mainDiv">
                <div class="howTo flexColumn">
                    <h2>HOW TO: Create an HTML form that utilizes PHP form handling that is Connected to a MySQL Database</h2>
                    <p id="goal">GOAL: The goal of this tutorial is to create an HTML form that utilizes PHP form handling which connects to a database. This form will be similar to the pre-built example on this page.</p>
                    <div class="contentDiv step">
                        <h3>Step #1: Creating an HTML Form</h3>
                        <p>The first step is to create a simple PHP form using the POST method</p>
                        <div class="example">
                            <p>Example:</p>
                            <div class="codeSegment">
                                <span class="exampleCode-line">< html><br> </span>
                                <span class="exampleCode-line">< body> <br></span> 
                                <span class="exampleCode-line">< form action="formInsert.php" method="POST"> <br> </span>
                                <span class="exampleCode-line">< label for="name">Name: </ label> <br> </span>
                                <span class="exampleCode-line">< input type="text" name="name"> <br> </span>
                                <span class="exampleCode-line">< label for="comfort_mysql"> On a scale of 1-5, how comfortable are you using MySQL? < /label> < br > <br> </span>
                                <span class="exampleCode-line">< select id="comfort_mysql" name="comfort_mysql"> < br > <br> </span>
                                    <span class="exampleCode-line indent">< option value="1">1</ option> < br > <br> </span>
                                    <span class="exampleCode-line indent">< option value="2">2</ option> < br > <br> </span>
                                    <span class="exampleCode-line indent">< option value="3">3</ option> < br > <br> </span>
                                    <span class="exampleCode-line indent">< option value="4">4</ option> < br > <br> </span>
                                    <span class="exampleCode-line indent">< option value="5">5</ option> < br > <br> </span>
                                <span class="exampleCode-line">< input type="submit"> <br></span>
                                <span class="exampleCode-line">< /form > <br> </span>
      
                                <span class="exampleCode-line">< /body> <br> </span>
                                <span class="exampleCode-line">< /html> </span>
                            </div>
                        </div>
                    </div>
                    <div class="contentDiv step">
                        <h3>Step #2: Creating the Database (surveyDB) and Table (survey_responses)</h3>
                        <p>The second step is create a new PHP file (buildDB.php). 
                            This file will be used to build the new surveyDB database and the table within the database using MySQLi - Object Oriented.</p>
                        <div class="example">
                            <p>Example:</p>
                            <span class="exampleCode-line"> < ?php <br> </span>
                                <div class="codeSegment">
                                    <span class="exampleCode-line"> $servername = "localhost"; <br> </span>
                                    <span class="exampleCode-line">$username = "myusername"; <br> </span>
                                    <span class="exampleCode-line"> $password = "myPassword" </span>
                                </div>
                                <div class="codeSegment">
                                    <p> <strong>Create the connection</strong> </p>
                                    <span class="exampleCode-line">$conn = new mysqli ($servername, $username, $password) <br> </span>
                                </div>
                            <div class="codeSegment">
                                <p> <strong>Check the connection</strong> </p>
                                <span class="exampleCode-line">if ($conn->connect_error){ <br> </span>
                                <span class="exampleCode-line indent">    die("Connection failed: " . $conn->connect_error);<br> </span>
                                <span class="exampleCode-line">}</span>
                            </div>
                            <div class="codeSegment">
                                <p> <strong> Create the database and table</strong></p>
                                <span class="exampleCode-line">$sql = "CREATE DATABASE surveyDB";<br> </span>
                                <span class="exampleCode-line">if ($conn->query($sql)=== TRUE) { <br> </span>
                                <span class="exampleCode-line indent"> echo "Database created successfuly";<br> </span>

                                <span class="exampleCode-line indent">$conn->select_db($surveyDB); <br> </span>
                                <span class="exampleCode-line indent">$tableSql = " <br> </span>
                                <span class="exampleCode-line indent">CREATE TABLE IF NOT EXISTS survey_responses ( <br> </span>
                                <span class="exampleCode-line indent">id INT(2) AUTO_INCREMENT PRIMARY KEY, <br> </span>
                                <span class="exampleCode-line indent">name VARCHAR(100), <br> </span>
                                <span class="exampleCode-line indent">comfort_mysql TINYINT CHECK (comfort_mysql BETWEEN 1 AND 5) <br> </span>
                                <span class="exampleCode-line indent">); <br> </span>
                                <span class="exampleCode-line indent">if ($conn->query($tableSql) === TRUE) { <br> </span>
                                <span class="exampleCode-line indent">echo "new table was created!"; <br> </span>
                                <span class="exampleCode-line indent">} else { <br> </span>
                                <span class="exampleCode-line indent">echo "Error creating table: " . $conn->error; <br> </span>
                                <span class="exampleCode-line indent">} <br> </span>
                                <span class="exampleCode-line">} else { <br> </span>
                                <span class="exampleCode-line indent">echo "Error creating database: " . $conn->error;<br> </span>
                                <span class="exampleCode-line">} <br> </span>
    
                                <span class="exampleCode-line">$conn->close(); <br> </span>
                                <span class="exampleCode-line">?></span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="contentDiv step">
                        <h3>Step #3: Retrieve Form Data and Execute SQL Statement in Database</h3>
                        <p>The third step is to create the "formInsert.php" PHP file used in the form action attribute during Step #1. 
                            The example PHP script below will connect to a pre-established database using MySQLi.
                            This will allow for the retrieval of form data using the $_POST method and the insertion of form data into the database by preparing
                             an SQL statement with a placeholder, binding a variable to the placeholder, and executing the statement.</p>
                        <div class="example">
                            <p>Example:</p>
                            <span class="exampleCode-line">Inside formInsert.php</p></span>
                            <div class="codeSegment">
                                <span class="exampleCode-line">< ?php <br> </span>
                                <span class="exampleCode-line">$servername = "localhost"; <br> </span>
                                <span class="exampleCode-line">$username = "myusername"; <br> </span>
                                <span class="exampleCode-line">$password = "myPassword" <br> </span>
                                <span class="exampleCode-line">$dbname = "surveyDB" </span>
                            </div>
                            <div class="codeSegment">
                                <p> <strong>Create the connection</strong> </p>
                                <span class="exampleCode-line">$conn = new mysqli($servername, $username, $password, $dbname)</span>
                            </div>
                            <div class="codeSegment">
                                <p> <strong>Check the connection</strong> </p>
                                <span class="exampleCode-line">if ($conn->connect_error){ <br> </span>
                                <span class="exampleCode-line indent">    die("Connection failed: " . $conn->connect_error);<br> </span>
                                <span class="exampleCode-line">}</span>
                            </div>
                            <div class="codeSegment">
                                <p> <strong>Retrieve the form data using $_POST and create an SQL INSERT statement.</strong> </p>
                                <span class="exampleCode-line">if ($_SERVER["REQUEST_METHOD"]=="POST") {<br> </span>
                                <span class="exampleCode-line indent">$name = $_POST['name']<br> </span>
                                <span class="exampleCode-line indent">$comfort_mysql = $_POST['comfort_mysql']<br> </span>
                                <span class="exampleCode-line indent">$stmt = $conn->prepare("INSERT INTO survey_responses (name, comfort_mysql) VALUES (?,?)");<br> </span>
                                <span class="exampleCode-line indent">$stmt = bind_param("si", $name, $comfort_mysql);<br> </span>
                                 <span class="exampleCode-line">}</span>
                            </div>
                            <div class="codeSegment">
                                <p> <strong>Execute the SQL statement</strong> </p>
                                <span class="exampleCode-line"> if ($stmt-execute()) {<br> </span>
                                <span class="exampleCode-line indent">    echo "New entry successful"; <br> </span>
                                <span class="exampleCode-line"> } else { <br> </span>
                                <span class="exampleCode-line indent"> echo "Error: " . $stmt->error; <br> </span>
                                <span class="exampleCode-line">}<br> </span>
                            
                                <span class="exampleCode-line">$stmt->close();<br> </span>

                                <span class="exampleCode-line">$conn->close();<br> </span>
                                <span class="exampleCode-line">?></span>
                            </div>
                        </div>
                    </div>
                </div> 

                <div class="form flexColumn">
                    <form action="formInsert.php" method="POST" id="formInsert" class="flexColumn">
                        <h3>Please answer the questions below - they will be inserted into a Database</h3>
                        
                        <label for="name">Name: </label>
                        <input type="text" name="name" required>
                        <!--  Bar Chart Questions  -->
                          <h4>The following questions are intended to evalulate your comfort level using various coding languages</h4>
                        <label for="comfort_mysql">On a scale of 1-5, how comfortable are you using MySQL?</label>
                        <select id="comfort_mysql" name="comfort_mysql" required>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                        <label for="comfort_php">On a scale of 1-5, how comfortable are you using PHP?</label>
                        <select id="comfort_php" name="comfort_php" required>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                        <label for="comfort_html">On a scale of 1-5, how comfortable are you using HTML?</label>
                        <select id="comfort_html" name="comfort_html" required>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                        <!--  Pie Chart Question  -->
                        <label for="favorite_bev">What is your favorite beverage while studying?</label>
                        <select id="favorite_bev" name="favorite_bev" required>
                            <option value="Coffee">Coffee</option>
                            <option value="Tea">Tea</option>
                            <option value="Water">Water</option>
                            <option value="Soda">Soda</option>
                            <option value="Energy Drink">Energy Drink</option>
                            <option value="Alcohol">Alcohol</option>
                        </select>
                        <!--  Spider Chart Questions  -->
                        <h4>The following questions are intended to evalulate 'Student Productivity Skills'</h4>
                        <label for="skill_time">On a scale of 0-9, how well do you manage time?</label>
                        <select id="skill_time" name="skill_time" required>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                            <option value="9">9</option>
                        </select>
                        <label for="skill_focus">On a scale of 0-9, how well do you maintain focus?</label>
                        <select id="skill_focus" name="skill_focus" required>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                            <option value="9">9</option>
                        </select>
                        <label for="skill_notes">On a scale of 0-9, how well do you take notes?</label>
                        <select id="skill_notes" name="skill_notes" required>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                            <option value="9">9</option>
                        </select>
                        <label for="skill_collab">On a scale of 0-9, how well do you collaborate with others?</label>
                        <select id="skill_collab" name="skill_collab" required>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                            <option value="9">9</option>
                        </select>
                        <label for="skill_problem">On a scale of 0-9, how well do you solve problems?</label>
                        <select id="skill_problem" name="skill_problem" required>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                            <option value="9">9</option>
                        </select>
                        <label for="skill_stress">On a scale of 0-9, how well do you manage stress?</label>
                        <select id="skill_stress" name="skill_stress" required>
                            <option value="0">0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                            <option value="9">9</option>
                        </select>
                        <!--Inserts data into the corresponding data fields within MySQL Database-->
                        <input type="submit" id="submitForm">
                    </form>
                </div>
            </div>
            <div class="lessons-nav flexColumn">
                <h3>More PHP MySQL Lessons</h3>
                <div>
                    <a class="lessonLink" href="updatingDB.php">Lesson: Using a Form to Update Data in a Database</a>
                    <a class="lessonLink" href="returnedQuery.php">Lesson: Displaying Returned Query Data</a>
                </div>
            </div>
        </main>
        <footer>
            <p>Group 4: Madeline Lucas, Dillon Barnhardt, Gerome Vergara</p>
            <p>Dr. John Gerdes</p>
            <p><a href="#top">To Top</a></p>
        </footer>
    </body>
</html>