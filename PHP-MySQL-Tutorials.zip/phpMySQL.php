<!DOCTYPE html>
<html lang="en">
    <head>
        <title>PHP MySQL Tutorials and Lessons</title>
        <link rel="stylesheet" href="css\style.css">
    </head>
    <body id="phpMySQL-page">
        <nav class="flexColumn">
            <div id="logo">
                <img src="imgs/PHP-MySQL-Logo_W_Group4.png" alt="Website Logo">
            </div>
            <div class="navTab">
                <a href="index.php">Home</a>
            </div>
            <div class="navTab">
                <a href="phpForm.php">PHP Form Tutorial</a>
            </div>
            <div class="navTab">
                <a href="phpMySQL.php" id="active">PHP MySQL Tutorials</a>
            </div>
            <div class="navTab subTab">
                <a href="phpFormDB.php">Inserting Data into a Database Using a Form</a>
            </div>
            <div class="navTab subTab">
                <a href="updatingDB.php">Updating Data in a Database Using a Form</a>
            </div>
            <div class="navTab subTab">
                <a href="returnedQuery.php">Displaying Data Returned via a Query in a Database</a>
            </div>
            <div class="navTab">
                <a href="dataVisualization.php">Data Visualization</a>
            </div>
        </nav>

        <header>
            <h1>PHP MySQL Tutorials/Lessons</h1>
        </header>
        <main>
            <div class="contentDiv" id="overview">
                <h2>Overview</h2>
                <p>This page illustrates the sequence of the PHP MySQL Tutorials from W3Schools. This page also provides links to three detailed and interactive PHP MySQL lessons. How to insert data into a database using a form, updating data in a database using a form, and displaying data returned via a query in a database. </p>
            </div>
            <div id="phpMySQL-links" class="flex">
                <ul>
                    <h3>PHP MySQL W3School Tutorials:</h3>
                    <li class="W3Schools-link"><a href="TestPHP.php">Test PHP Operation</a></li>
                    <li class="W3Schools-link"><a href="Connect-MySQLiProcedural.php">MySQL Connect DB - MySQLi Procedural</a></li>
                    <li class="W3Schools-link"><a href="Connect-MySQLiOO.php">MySQL Connect DB - MySQLi Object Oriented</a></li>
                    <li class="W3Schools-link"><a href="CreateDB.php">MySQL Create DB</a></li>
                    <li class="W3Schools-link"><a href="Connect-PDO.php">MySQL Connect DB - PDO</a></li>
                    <li class="W3Schools-link"><a href="CreateTable.php">MySQL Create Table</a></li>
                    <li class="W3Schools-link"><a href="InsertData.php">MySQL Insert Data</a></li>
                    <li class="W3Schools-link"><a href="InsertData-with-Form.php">MySQL Insert Data with a Form</a></li>
                    <li class="W3Schools-link"><a href="GetLastID.php">MySQL Get Last ID</a></li>
                    <li class="W3Schools-link"><a href="InsertMultiple.php">MySQL Insert Multiple</a></li>
                    <li class="W3Schools-link"><a href="Prepared.php">MySQL Prepared</a></li>
                    <li class="W3Schools-link"><a href="Select-Data.php">MySQL Select Data</a></li>
                    <li class="W3Schools-link"><a href="Where.php">MySQL Where</a></li>
                    <li class="W3Schools-link"><a href="OrderBy.php">MySQL Order By</a></li>
                    <li class="W3Schools-link"><a href="Delete.php">MySQL Delete</a></li>
                    <li class="W3Schools-link"><a href="Update.php">MySQL Update</a></li>
                    <li class="W3Schools-link"><a href="Limit.php">MySQL Limit</a></li>
                </ul>
                <ul>
                    <h3>PHP MySQL Lessons:</h3>
                    <li class="lessonLink"><a href="phpFormDB.php">Lesson: Using a Form to Input Data into a Database</a></li>
                    <li class="lessonLink"><a href="updatingDB.php">Lesson: Using a Form to Update Data in a Database</a></li>
                    <li class="lessonLink"><a href="returnedQuery.php">Lesson: Displaying Data Returned from a Database Query</a></li>
                </ul>
            </div>
        </main>
        <footer>
            <p>Group 4: Madeline Lucas, Dillon Barnhardt, Gerome Vergara</p>
            <p>Dr. John Gerdes</p>
            <p><a href="#top">To Top</a></p>
        </footer>
    </body>
</html>