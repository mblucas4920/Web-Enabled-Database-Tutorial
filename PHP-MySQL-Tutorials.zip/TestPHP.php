<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>PHP Test Tutorial</title>
  <link rel="stylesheet" href="css\style.css">
</head>
<body>
  <nav class="flexColumn">
    <div id="logo">
      <img src="imgs/PHP-MySQL-Logo_W_Group4.png" alt="Website Logo">
    </div>
    <div class="navTab">
      <a href="index.php">Home</a>
    </div>
    <div class="navTab">
      <a href="phpForm.php">PHP Form Tutorial</a>
    </div>
    <div class="navTab">
      <a href="phpMySQL.php" id="active">PHP MySQL Tutorials</a>
    </div>
    <div class="navTab subTab">
      <a href="phpFormDB.php">Inserting Data into a Database Using a Form</a>
    </div>
    <div class="navTab subTab">
      <a href="updatingDB.php">Updating Data in a Database Using a Form</a>
    </div>
    <div class="navTab subTab">
      <a href="returnedQuery.php">Displaying Data Returned via a Query in a Database</a>
    </div>
    <div class="navTab">
      <a href="dataVisualization.php">Data Visualization</a>
    </div>
  </nav>
  <header>
    <h1>Testing PHP on Your Server</h1>
  </header>
  
  <main class="W3Schools-main">
    <h2>Step 1: Understanding This Page</h2>
    <p>This page helps you verify if PHP is working properly on your local server. 
    If PHP is installed correctly, you’ll see a message below that says <strong>"PHP Worked!"</strong>.</p>

    <h2>Step 2: PHP Output</h2>
    <p>Here’s the live PHP output:</p>
    <p>
      <?php
        echo "PHP Worked!";
      ?>
    </p>

    <h2>Step 3: How the Code Works</h2>
    <p>The PHP code used on this page looks like this:</p>
    <pre>
      &lt;?php
        echo "PHP Worked!";
      ?&gt;
    </pre>
    <p>This tells the server to execute PHP code and display the result on your webpage.</p>

    <h2>Return to the Menu</h2>
    <p>Once you’ve confirmed PHP is working, you can return to your main site menu below.</p>
    <a href="phpMySQL.php">Return to Menu</a>
  </main>
  <footer>
      <p>Group 4: Madeline Lucas, Dillon Barnhardt, Gerome Vergara</p>
      <p>Dr. John Gerdes</p>
      <p><a href="#top">To Top</a></p>
  </footer>
</body>
</html>