<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Prepared Statements</title>
  <link rel="stylesheet" href="css\style.css">
</head>
<body id="W3Schools-page">
  <nav class="flexColumn">
    <div id="logo">
      <img src="imgs/PHP-MySQL-Logo_W_Group4.png" alt="Website Logo">
    </div>
    <div class="navTab">
      <a href="index.php">Home</a>
    </div>
    <div class="navTab">
      <a href="phpForm.php">PHP Form Tutorial</a>
    </div>
    <div class="navTab">
      <a href="phpMySQL.php" id="active">PHP MySQL Tutorials</a>
    </div>
    <div class="navTab subTab">
      <a href="phpFormDB.php">Inserting Data into a Database Using a Form</a>
    </div>
    <div class="navTab subTab">
      <a href="updatingDB.php">Updating Data in a Database Using a Form</a>
    </div>
    <div class="navTab subTab">
      <a href="returnedQuery.php">Displaying Data Returned via a Query in a Database</a>
    </div>
    <div class="navTab">
      <a href="dataVisualization.php">Data Visualization</a>
    </div>
  </nav>
  <header>
    <h1>Insert Records Using Prepared Statements</h1>
    <a href="https://www.w3schools.com/php/php_mysql_prepared_statements.asp" class="headerLink">W3Schools Link</a>
  </header>
  <main class="W3Schools-main">
    <h2>Step 1: Understanding This Page</h2>
    <p>This page demonstrates how to insert multiple records into the <strong>MyGuests</strong> table using <strong>prepared statements</strong> with <code>mysqli</code>. 
    Prepared statements improve security and prevent SQL injection.</p>

    <h2>Step 2: PHP Output</h2>
    <p>Below is the live output from the prepared statement inserts:</p>
    <p>
      <?php
        $servername = "localhost";
        $username = "myusername";
        $password = "myPassword";
        $dbname = "myDB";

        // Create connection
        $conn = mysqli_connect($servername, $username, $password, $dbname);

        // Check connection
        if (!$conn) {
          die("Connection failed: " . mysqli_connect_error());
        }

        // Prepare and bind
        $stmt = mysqli_prepare($conn, "INSERT INTO MyGuests (firstname, lastname, email) VALUES (?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "sss", $firstname, $lastname, $email);

        // Set parameters and execute
        $firstname = "John";
        $lastname = "Doe";
        $email = "john@example.com";
        mysqli_stmt_execute($stmt);

        $firstname = "Mary";
        $lastname = "Moe";
        $email = "mary@example.com";
        mysqli_stmt_execute($stmt);

        $firstname = "Julie";
        $lastname = "Dooley";
        $email = "julie@example.com";
        mysqli_stmt_execute($stmt);

        echo "New records created successfully";

        mysqli_stmt_close($stmt);
        mysqli_close($conn);
      ?>
    </p>

    <h2>Step 3: How the Code Works</h2>
    <p>The code connects to the database, prepares an SQL statement with placeholders, binds variables to the placeholders, 
    and executes the statement multiple times to insert multiple records safely. Prepared statements help prevent SQL injection.</p>

    <pre>
      &lt;?php
      $conn = mysqli_connect($servername, $username, $password, $dbname);

      if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
      }

      $stmt = mysqli_prepare($conn, "INSERT INTO MyGuests (firstname, lastname, email) VALUES (?, ?, ?)");
      mysqli_stmt_bind_param($stmt, "sss", $firstname, $lastname, $email);

      $firstname = "John";
      $lastname = "Doe";
      $email = "john@example.com";
      mysqli_stmt_execute($stmt);

      $firstname = "Mary";
      $lastname = "Moe";
      $email = "mary@example.com";
      mysqli_stmt_execute($stmt);

      $firstname = "Julie";
      $lastname = "Dooley";
      $email = "julie@example.com";
      mysqli_stmt_execute($stmt);

      echo "New records created successfully";

      mysqli_stmt_close($stmt);
      mysqli_close($conn);
      ?&gt;
    </pre>

    <h2>Return to the Menu</h2>
    <a href="phpMySQL.php">Return to Menu</a>
    </main>
  <footer>
      <p>Group 4: Madeline Lucas, Dillon Barnhardt, Gerome Vergara</p>
      <p>Dr. John Gerdes</p>
      <p><a href="#top">To Top</a></p>
  </footer>
</body>
</html>