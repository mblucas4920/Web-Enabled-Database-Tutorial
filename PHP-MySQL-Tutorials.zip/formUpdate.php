<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Database Updated</title>
  <link rel="stylesheet" href="css\style.css">
</head>
<body id="entry-page">
  <nav class="flexColumn">
    <div id="logo">
      <img src="imgs/PHP-MySQL-Logo_W_Group4.png" alt="Website Logo">
    </div>
    <div class="navTab">
      <a href="index.php">Home</a>
    </div>
    <div class="navTab">
      <a href="phpForm.php">PHP Form Tutorial</a>
    </div>
    <div class="navTab">
      <a href="phpMySQL.php">PHP MySQL Tutorials</a>
    </div>
    <div class="navTab subTab">
      <a href="phpFormDB.php">Inserting Data into a Database Using a Form</a>
    </div>
    <div class="navTab subTab">
      <a href="updatingDB.php" id="active">Updating Data in a Database Using a Form</a>
    </div>
    <div class="navTab subTab">
      <a href="returnedQuery.php">Displaying Data Returned via a Query in a Database</a>
    </div>
    <div class="navTab">
      <a href="dataVisualization.php">Data Visualization</a>
    </div>
  </nav>
  <header>
    <h1>Database Updated</h1>
  </header>
    <main class="flexColumn">
      <div id="entryContent" class="flexColumn">
        <?php 
            $servername="localhost";
            $username="myusername";
            $password="myPassword";
            $dbname="surveyDB";

            $conn = new mysqli($servername,$username,$password,$dbname);

            if ($conn->connect_error){
                die("Connection failed: " . $conn->connect_error);
            }

            if($_SERVER["REQUEST_METHOD"]=="POST"){
                $name=$_POST['name'];
                $comfort_mysql=$_POST['comfort_mysql'];
                $comfort_php=$_POST['comfort_php'];
                $comfort_html=$_POST['comfort_html'];
                $favorite_bev=$_POST['favorite_bev'];
                $skill_time =$_POST['skill_time'];
                $skill_focus =$_POST['skill_focus'];
                $skill_notes =$_POST['skill_notes'];
                $skill_collab =$_POST['skill_collab'];
                $skill_problem =$_POST['skill_problem'];
                $skill_stress =$_POST['skill_stress'];
                $newest_entry=$_POST;
                $stmt = $conn->prepare("UPDATE survey_responses SET name = ?, comfort_mysql = ?, comfort_php = ?, comfort_html = ?, favorite_beverage = ?,
                skill_time = ?, skill_focus = ?, skill_notes = ?, skill_collab = ?, skill_problem = ?, skill_stress = ? WHERE id=(SELECT MAX(id) FROM survey_responses)");
                $stmt->bind_param("siiisiiiiii", $name, $comfort_mysql,$comfort_php,$comfort_html,$favorite_bev,$skill_time,$skill_focus,$skill_notes,$skill_collab,$skill_problem,$skill_stress );
            }

            if($stmt->execute()){
                echo "Entry update successful";
            } else {
                echo "Error: " . $stmt->error;
            }
            $stmt->close();
            $conn->close();
          ?>
          <div id="return">
            <a href="updatingDB.php">Return to previous page</a>
          </div>
      </div>
      <div class="lessons-nav" id="results">
          <h3>View your entry at the following pages...</h3>
          <div>
              <a class="lessonLink" href="returnedQuery.php">Lesson: Displaying Returned Query Data</a>
              <a class="lessonLink" href="dataVisualization.php">Data Visualization Page</a>
          </div>
      </div>
    </main>
    <footer>
        <p>Group 4: Madeline Lucas, Dillon Barnhardt, Gerome Vergara</p>
        <p>Dr. John Gerdes</p>
        <p><a href="#top">To Top</a></p>
    </footer>
</body>
</html>