<?php
// dataVisualization.php - Pie, Column, and Radar Charts using comfort, beverage, and skill data
$servername = "localhost";
$username = "myusername";
$password = "myPassword";
$dbname = "surveydb";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) { die("Connection failed: " . mysqli_connect_error()); }

// --------- PIE CHART: Favorite Beverage ---------
$bev_sql = "SELECT favorite_beverage, COUNT(*) AS total FROM survey_responses GROUP BY favorite_beverage";
$bev_result = mysqli_query($conn, $bev_sql);
$bev_labels = [];
$bev_values = [];
while ($row = mysqli_fetch_assoc($bev_result)) {
    $bev_labels[] = $row['favorite_beverage'];
    $bev_values[] = $row['total'];
}
$jsBevLabels = json_encode($bev_labels);
$jsBevValues = json_encode($bev_values);

// --------- COLUMN CHART: Comfort Levels ---------
$comfort_sql = "SELECT AVG(comfort_mysql) AS mysql_avg, AVG(comfort_php) AS php_avg, AVG(comfort_html) AS html_avg FROM survey_responses";
$comfort_result = mysqli_query($conn, $comfort_sql);
$comfort_labels = ['MySQL', 'PHP', 'HTML'];
$comfort_values = [];
if ($row = mysqli_fetch_assoc($comfort_result)) {
    $comfort_values = [round($row['mysql_avg'],1), round($row['php_avg'],1), round($row['html_avg'],1)];
}
$jsComfortLabels = json_encode($comfort_labels);
$jsComfortValues = json_encode($comfort_values);

// --------- RADAR CHART: Skill Levels ---------
$skill_sql = "SELECT AVG(skill_time) AS time_avg, AVG(skill_focus) AS focus_avg, AVG(skill_notes) AS notes_avg, AVG(skill_collab) AS collab_avg, AVG(skill_problem) AS problem_avg, AVG(skill_stress) AS stress_avg FROM survey_responses";
$skill_result = mysqli_query($conn, $skill_sql);
$skill_labels = ['Time', 'Focus', 'Notes', 'Collaboration', 'Problem-Solving', 'Stress'];
$skill_values = [];
if ($row = mysqli_fetch_assoc($skill_result)) {
    $skill_values = [round($row['time_avg'],1), round($row['focus_avg'],1), round($row['notes_avg'],1), round($row['collab_avg'],1), round($row['problem_avg'],1), round($row['stress_avg'],1)];
}
$jsSkillLabels = json_encode($skill_labels);
$jsSkillValues = json_encode($skill_values);

mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Data Visualization - Comfort, Beverage, Skills</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body id="dataViz-page">
<nav class="flexColumn">
    <div id="logo">
        <img src="imgs/PHP-MySQL-Logo_W_Group4.png" alt="Website Logo">
    </div>
    <div class="navTab"><a href="index.php">Home</a></div>
    <div class="navTab"><a href="phpForm.php">PHP Form Tutorial</a></div>
    <div class="navTab"><a href="phpMySQL.php">PHP MySQL Tutorials</a></div>
    <div class="navTab subTab"><a href="phpFormDB.php">Inserting Data into a Database Using a Form</a></div>
    <div class="navTab subTab"><a href="updatingDB.php">Updating Data in a Database Using a Form</a></div>
    <div class="navTab subTab"><a href="returnedQuery.php">Displaying Data Returned via a Query in a Database</a></div>
    <div class="navTab" ><a href="dataVisualization.php" id="active">Data Visualization</a></div>
</nav>

<header>
    <h1>Data Visualization with PHP and MySQLi</h1>
</header>

<main class="contentDiv">

    <!-- TUTORIAL SECTION -->
    <h2>Step 1: Understanding This Page</h2>
    <p>This tutorial demonstrates how to generate three types of charts using <strong>PHP, MySQLi, and Chart.js</strong>. The page does the following:</p>
    <ul>
        <li>Connects to the database using <strong>MySQLi</strong></li>
        <li>Fetches survey data and calculates averages/counts for each chart</li>
        <li>Passes the data to JavaScript via JSON for Chart.js rendering</li>
        <li>Displays Pie, Column, and Radar charts</li>
    </ul>

    <h2>Step 2: Database Columns Used</h2>
    <p><strong>Comfort Chart (Column):</strong> <code>comfort_mysql, comfort_php, comfort_html</code><br>
       <strong>Beverage Chart (Pie):</strong> <code>favorite_beverage</code><br>
       <strong>Skill Chart (Radar):</strong> <code>skill_time, skill_focus, skill_notes, skill_collab, skill_problem, skill_stress</code></p>

    <h2>Step 3: How Charts are Built</h2>
    <p>The process is:</p>
    <ol>
        <li>Query database and aggregate data using <code>AVG()</code> for numeric columns or <code>COUNT()</code> for categorical columns</li>
        <li>Encode PHP arrays as JSON using <code>json_encode()</code></li>
        <li>Use Chart.js to render charts dynamically in the browser</li>
    </ol>

    <!-- DROPDOWN CHARTS -->
     <div id ="dropdownCharts" class="flex">
        <div class="panel">
            <button class="accordion button">Pie Chart - Favorite Beverage</button>
            <canvas class="chart" id="pieChart"></canvas>
        </div>
        
        <div class="panel">
            <button class="accordion button">Column Chart - Comfort Levels</button>
            <canvas class="chart" id="columnChart"></canvas>
        </div>

        <div class="panel">
            <button class="accordion button">Radar Chart - Skill Levels</button>
            <canvas class="chart" id="radarChart"></canvas>
        </div>
    </div>
</main>

<script>
// Accordion functionality: all panels start closed
const acc = document.getElementsByClassName("accordion");
for (let i = 0; i < acc.length; i++) {
    const panel = acc[i].nextElementSibling;
    panel.style.display = "none";  // ensure closed on load

    acc[i].addEventListener("click", function() {
        panel.style.display = panel.style.display === "block" ? "none" : "block";
        this.classList.toggle("active");
    });
}

// Chart.js rendering
function getRandomColors(n) {
    let colors = [];
    for (let i=0; i<n; i++) {
        colors.push('#'+Math.floor(Math.random()*16777215).toString(16));
    }
    return colors;
}

const pieLabels = <?php echo $jsBevLabels; ?>;
const pieValues = <?php echo $jsBevValues; ?>;
const comfortLabels = <?php echo $jsComfortLabels; ?>;
const comfortValues = <?php echo $jsComfortValues; ?>;
const skillLabels = <?php echo $jsSkillLabels; ?>;
const skillValues = <?php echo $jsSkillValues; ?>;

const pieColors = getRandomColors(pieLabels.length);
const comfortColors = getRandomColors(comfortLabels.length);
const skillColors = getRandomColors(skillLabels.length);

// Pie Chart
new Chart(document.getElementById('pieChart').getContext('2d'), {
    type: 'pie',
    data: { labels: pieLabels, datasets: [{ data: pieValues, backgroundColor: pieColors }] },
    options: { responsive: true, plugins: { legend: { position: 'bottom' } } }
});

// Column Chart
new Chart(document.getElementById('columnChart').getContext('2d'), {
    type: 'bar',
    data: { labels: comfortLabels, datasets: [{ label: 'Average Comfort', data: comfortValues, backgroundColor: comfortColors }] },
    options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
});

// Radar Chart
new Chart(document.getElementById('radarChart').getContext('2d'), {
    type: 'radar',
    data: { labels: skillLabels, datasets: [{ label: 'Average Skill', data: skillValues, backgroundColor: 'rgba(54,162,235,0.2)', borderColor: 'rgba(54,162,235,1)', pointBackgroundColor: skillColors }] },
    options: { responsive: true, scales: { r: { beginAtZero: true } } }
});
</script>

<footer>
    <p>Group 4: Madeline Lucas, Dillon Barnhardt, Gerome Vergara</p>
    <p>Dr. John Gerdes</p>
    <p><a href="#top">To Top</a></p>
</footer>

</body>
</html>