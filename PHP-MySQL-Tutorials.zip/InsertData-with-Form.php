<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Insert Data with Form</title>
  <style>
    .error {color: #FF0000;}
  </style>
  <link rel="stylesheet" href="css\style.css">
</head>
<body id="W3Schools-page">
  <nav class="flexColumn">
    <div id="logo">
      <img src="imgs/PHP-MySQL-Logo_W_Group4.png" alt="Website Logo">
    </div>
    <div class="navTab">
      <a href="index.php">Home</a>
    </div>
    <div class="navTab">
      <a href="phpForm.php">PHP Form Tutorial</a>
    </div>
    <div class="navTab">
      <a href="phpMySQL.php" id="active">PHP MySQL Tutorials</a>
    </div>
    <div class="navTab subTab">
      <a href="phpFormDB.php">Inserting Data into a Database Using a Form</a>
    </div>
    <div class="navTab subTab">
      <a href="updatingDB.php">Updating Data in a Database Using a Form</a>
    </div>
    <div class="navTab subTab">
      <a href="returnedQuery.php">Displaying Data Returned via a Query in a Database</a>
    </div>
    <div class="navTab">
      <a href="dataVisualization.php">Data Visualization</a>
    </div>
  </nav>
  <header>
    <h1>Insert Data with Form</h1>
    <a href="https://www.w3schools.com/php/php_mysql_insert.asp" class="headerLink">W3Schools Link</a>
  </header>
  <main class="W3Schools-main">
    <h2>Step 1: Understanding This Page</h2>
    <p>This page allows you to insert a new record into the <strong>MyGuests</strong> table using a form. 
    All fields are validated before saving to ensure proper input.</p>

    <h2>Step 2: PHP Output</h2>
    <p>Below is the live output and form:</p>

    <?php
    $servername = "localhost";
    $username = "myusername";
    $password = "myPassword";
    $dbname = "myDB";

    $fnameErr = $lnameErr = $emailErr = "";
    $fname = $lname = $email = "";
    $inputerror = "";
    $saved = "";

    function test_input($data) {
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
    }

    // Process form submission
    if ($_SERVER["REQUEST_METHOD"] == "POST") {

      if (empty($_POST["fname"])) {
        $fnameErr = "First Name is required";
        $inputerror = "error";
      } else {
        $fname = test_input($_POST["fname"]);
        if (!preg_match("/^[a-zA-Z-' ]*$/", $fname)) {
          $fnameErr = "Only letters and white space allowed";
          $inputerror = "error";
        }
      }

      if (empty($_POST["lname"])) {
        $lnameErr = "Last Name is required";
        $inputerror = "error";
      } else {
        $lname = test_input($_POST["lname"]);
        if (!preg_match("/^[a-zA-Z-' ]*$/", $lname)) {
          $lnameErr = "Only letters and white space allowed";
          $inputerror = "error";
        }
      }

      if (empty($_POST["email"])) {
        $emailErr = "Email is required";
        $inputerror = "error";
      } else {
        $email = test_input($_POST["email"]);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
          $emailErr = "Invalid email format";
          $inputerror = "error";
        }
      }

      $saved = $_POST['saved'] ?? "";

      if ($inputerror != "error" && $saved != "Y") {
        $conn = mysqli_connect($servername, $username, $password, $dbname);
        if (!$conn) {
          die("Connection failed: " . mysqli_connect_error());
        }

        $sql = "INSERT INTO MyGuests (firstname, lastname, email) VALUES ('$fname', '$lname', '$email')";
        if (mysqli_query($conn, $sql)) {
          $saved = "Y";
          $fname = $lname = $email = "";
        } else {
          echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }

        mysqli_close($conn);
      }

      if ($inputerror == "error") {
        echo "<p class='error'>Please correct input errors</p>";
      }
    ?>

    <?php } ?>

    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
      First Name: <input type="text" name="fname" value="<?php echo $fname;?>">
      <span class="error">* <?php echo $fnameErr;?></span>
      <br><br> 
      Last Name: <input type="text" name="lname" value="<?php echo $lname;?>">
      <span class="error">* <?php echo $lnameErr;?></span>
      <br><br>
      E-mail: <input type="text" name="email" value="<?php echo $email;?>">
      <span class="error">* <?php echo $emailErr;?></span>
      <br><br>
      <input type="hidden" name="saved" value="<?php echo $saved;?>">
      <input type="submit" name="submit" value="Submit"> 
    </form>

    <?php
    if ($saved == "Y") {
      echo "<br>New record created successfully<br>";
    }
    ?>

    <h2>Step 3: How the Code Works</h2>
    <p>The code validates user input, connects to the database, and inserts a new record into the <strong>MyGuests</strong> table. 
    It displays errors if the input is invalid and confirms when a record is successfully added.</p>

    <pre>
    &lt;?php
    // Define variables and validate input as shown above

    $conn = mysqli_connect($servername, $username, $password, $dbname);

    if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
    }

    $sql = "INSERT INTO MyGuests (firstname, lastname, email) VALUES ('$fname', '$lname', '$email')";

    if (mysqli_query($conn, $sql)) {
      $saved = "Y";
      $fname = $lname = $email = "";
    } else {
      echo "Error: " . $sql . "&lt;br&gt;" . mysqli_error($conn);
    }

    mysqli_close($conn);
    ?&gt;
    </pre>

    <h2>Return to the Menu</h2>
    <a href="phpMySQL.php">Return to Menu</a>
  </main>
  <footer>
    <p>Group 4: Madeline Lucas, Dillon Barnhardt, Gerome Vergara</p>
    <p>Dr. John Gerdes</p>
    <p><a href="#top">To Top</a></p>
  </footer>
</body>
</html>