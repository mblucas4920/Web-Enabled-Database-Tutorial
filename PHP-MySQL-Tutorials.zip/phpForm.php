<!DOCTYPE html>
<html lang="en">
    <head>
        <title>PHP MySQL Tutorial Website - Homepage</title>
        <link rel="stylesheet" href="css\style.css">
        <script src="javascript\script.js"></script>
    </head>
    <body id="phpForm" class="tutorialPage">
<!--goal of this page is to teach students how to create a simple form using HTML in an PHP file -->
        <nav class="flexColumn">
            <div id="logo">
                <img src="imgs/PHP-MySQL-Logo_W_Group4.png" alt="Website Logo">
            </div>
            <div class="navTab">
                <a href="index.php">Home</a>
            </div>
            <div class="navTab">
                <a href="phpForm.php" id="active">PHP Form Tutorial</a>
            </div>
            <div class="navTab">
                <a href="phpMySQL.php">PHP MySQL Tutorials</a>
            </div>
            <div class="navTab subTab">
                <a href="phpFormDB.php">Inserting Data into a Database Using a Form</a>
            </div>
            <div class="navTab subTab">
                <a href="updatingDB.php">Updating Data in a Database Using a Form</a>
            </div>
            <div class="navTab subTab">
                <a href="returnedQuery.php">Displaying Data Returned via a Query in a Database</a>
            </div>
            <div class="navTab">
                <a href="dataVisualization.php">Data Visualization</a>
            </div>
        </nav>

        <header>
            <h1>PHP/HTML Form Tutorial</h1>
        </header>
        <main>
            <div class="howTo">
                <h2>HOW TO: Create an HTML form that utilizes PHP form handling.</h2>
                <p id="goal">GOAL: The goal of this tutorial is to create a simple HTML form that utilizes PHP form handling with no database connections.</p>
                <div class="contentDiv step">
                    <h3>Step #1: Simple HTML Form - POST Method</h3>
                    <p>Create a simple form in PHP using the < form > element with the "POST" method in HTML.</p>
                    <div class="example">
                        <p>Example:</p>
                        <div class="codeSegment">
                            <span class="exampleCode-line">< html> <br> </span>
                            <span class="exampleCode-line">< body> <br> </span>
                                <span class="exampleCode-line indent">  < form action="welcome.php" method="POST"> <br> </span>
                                <span class="exampleCode-line indent"> Name: < input type="text" name="name"> < br > <br> </span>
                                <span class="exampleCode-line indent"> E-mail: < input type="text" name="email"> < br > <br> </span>
                                <span class="exampleCode-line indent">< input type="submit"> <br> </span>
                                <span class="exampleCode-line indent"> < /form > <br> </span>
                            <span class="exampleCode-line">< /body> <br> </span>
                            <span class="exampleCode-line">< /html> </span>
                        </div>
                    </div>
                </div>
                <div class="contentDiv step">
                    <h3>Step #2: Creating the Output (welcome.php) </h3>
                    <p>To display the submitted data you must echo all the variables in a file titled "welcome.php" that looks like the following: </p>
                    <div class="example">
                        <p>Example: </p>
                        <div class="codeSegment">
                            <span class="exampleCode-line">< html> <br> </span>
                            <span class="exampleCode-line">< body> <br> </span>
                                <span class="exampleCode-line indent"> Welcome < ?php echo $_POST["name"]; ?> < br > <br> </span>
                                <span class="exampleCode-line indent"> Your email address is: < ?php echo $_POST["email"]; ?> < br > <br> </span>
                            <span class="exampleCode-line">< /body> <br> </span>
                            <span class="exampleCode-line">< /html> </span>
                        </div>
                    </div>
                </div>
                <div class="contentDiv step">
                    <h3>Step #3: Output</h3>
                    <p>The output could be something like this:</p>
                    <p>Example: <br>
                        &nbsp; Welcome John Doe <br>
                        &nbsp; Your email address is: john.doe@example.com
                    </p>
                </div>
            </div> 

            <div class="form flexColumn">
                <form action="phpForm.php" method="POST" class="flexColumn">
                    <h2>PHP Form</h2>
                    Name: <input type="text" name="name"><br>
                    How much PHP do you know? 
                    <select name="currentKnowledge" id="currentKnowledge">
                        <option value="NO">None</option>
                        <option value="SOME">A little</option>
                        <option value="GREAT">A lot</option>
                    </select>
                    <br>
                    <input type="submit" value="Submit" id="submitForm" >
                </form>
                <button class="button" onclick="showOutput()" id="showOutput">Show Results</button>
                <div id="hidden-div" class="contentDiv">
                    Hello <strong> <?php echo $_POST["name"]; ?> </strong>
                    <br>
                    You have <strong> <?php echo $_POST["currentKnowledge"]; ?> </strong> PHP knowledge.
                    <br> We hope this website teaches you more!
                </div>
            </div>
        </main>
        <footer>
            <p>Group 4: Madeline Lucas, Dillon Barnhardt, Gerome Vergara</p>
            <p>Dr. John Gerdes</p>
            <p><a href="#top">To Top</a></p>
        </footer>
    </body>
</html>