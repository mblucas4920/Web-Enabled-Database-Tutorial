<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Insert and Get Last ID</title>
  <link rel="stylesheet" href="css\style.css">
</head>
<body id="W3Schools-page">
<nav class="flexColumn">
    <div id="logo">
      <img src="imgs/PHP-MySQL-Logo_W_Group4.png" alt="Website Logo">
    </div>
    <div class="navTab">
      <a href="index.php">Home</a>
    </div>
    <div class="navTab">
      <a href="phpForm.php">PHP Form Tutorial</a>
    </div>
    <div class="navTab">
      <a href="phpMySQL.php" id="active">PHP MySQL Tutorials</a>
    </div>
    <div class="navTab subTab">
      <a href="phpFormDB.php">Inserting Data into a Database Using a Form</a>
    </div>
    <div class="navTab subTab">
      <a href="updatingDB.php">Updating Data in a Database Using a Form</a>
    </div>
    <div class="navTab subTab">
      <a href="returnedQuery.php">Displaying Data Returned via a Query in a Database</a>
    </div>
    <div class="navTab">
      <a href="dataVisualization.php">Data Visualization</a>
    </div>
  </nav>
  <header>
    <h1>Insert Record and Get Last ID</h1>
    <a href="https://www.w3schools.com/php/php_mysql_insert_lastid.asp" class="headerLink">W3Schools Link</a>
  </header>
  <main class="W3Schools-main">
    <h2>Step 1: Understanding This Page</h2>
    <p>This page inserts a new record into the <strong>MyGuests</strong> table and then retrieves the last inserted ID using <code>mysqli_insert_id()</code>.</p>

    <h2>Step 2: PHP Output</h2>
    <p>Below is the live output of the insertion and the last inserted ID:</p>
    <p>
      <?php
        $servername = "localhost";
        $username = "myusername";
        $password = "myPassword";
        $dbname = "myDB";

        // Create connection
        $conn = mysqli_connect($servername, $username, $password, $dbname);

        // Check connection
        if (!$conn) {
          die("Connection failed: " . mysqli_connect_error());
        }

        // Insert a new record
        $sql = "INSERT INTO MyGuests (firstname, lastname, email) VALUES ('John', 'Doe', 'john@example.com')";

        if (mysqli_query($conn, $sql)) {
          $last_id = mysqli_insert_id($conn);
          echo "New record created successfully. Last inserted ID is: " . $last_id;
        } else {
          echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }

        mysqli_close($conn);
      ?>
    </p>

    <h2>Step 3: How the Code Works</h2>
    <p>The code connects to the database, inserts a new record, and then retrieves the last inserted ID using <code>mysqli_insert_id()</code>. 
    This ID is useful when you need to reference the newly created record in subsequent operations.</p>

    <pre>
      &lt;?php
      $conn = mysqli_connect($servername, $username, $password, $dbname);

      if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
      }

      $sql = "INSERT INTO MyGuests (firstname, lastname, email) VALUES ('John', 'Doe', 'john@example.com')";

      if (mysqli_query($conn, $sql)) {
        $last_id = mysqli_insert_id($conn);
        echo "New record created successfully. Last inserted ID is: " . $last_id;
      } else {
        echo "Error: " . $sql . "&lt;br&gt;" . mysqli_error($conn);
      }

      mysqli_close($conn);
      ?&gt;
    </pre>

    <h2>Return to the Menu</h2>
    <a href="phpMySQL.php">Return to Menu</a>
  </main>
  <footer>
    <p>Group 4: Madeline Lucas, Dillon Barnhardt, Gerome Vergara</p>
    <p>Dr. John Gerdes</p>
    <p><a href="#top">To Top</a></p>
  </footer>
</body>
</html>