<!DOCTYPE html>
<html lang="en">
    <head>
        <title>PHP MySQL Tutorial Website - Homepage</title>
        <link rel="stylesheet" href="css\style.css">
    </head>
    <body id="homePage">
        <nav class="flexColumn">
            <div id="logo">
                <img src="imgs/PHP-MySQL-Logo_W_Group4.png" alt="Website Logo">
            </div>
            <div class="navTab">
                <a href="index.php" id="active">Home</a>
            </div>
            <div class="navTab">
                <a href="phpForm.php">PHP Form Tutorial</a>
            </div>
            <div class="navTab">
                <a href="phpMySQL.php">PHP MySQL Tutorials</a>
            </div>
            <div class="navTab subTab">
                <a href="phpFormDB.php">Inserting Data into a Database Using a Form</a>
            </div>
            <div class="navTab subTab">
                <a href="updatingDB.php">Updating Data in a Database Using a Form</a>
            </div>
            <div class="navTab subTab">
                <a href="returnedQuery.php">Displaying Data Returned via a Query in a Database</a>
            </div>
            <div class="navTab">
                <a href="dataVisualization.php">Data Visualization</a>
            </div>
        </nav>

        <header>
            <h1>PHP MySQL Tutorial Website</h1>
        </header>

        <main>
            <div class="contentDiv flexColumn" id="overview">
                <h2>Overview</h2>
                <p>The goal of this website is to demonstrate how to utilize PHP to connect a website to a MySQL Database. This website will also demonstrate how to perform CRUD operations and to also generate various types of graphs based on data drawn from the database. </p>
            </div>
            <div id="links" class="flexColumn">
                <div class="contentDiv pageDesc">
                    <a href="phpForm.php"><h3>PHP Form Page</h3></a>
                    <p>This page is a tutorial that demonstrates the process of creating a form using PHP code. This form does NOT utilize MySQL or connect to a database. Click to learn more about the steps required to successfully create a PHP form and interact with a pre-built example form. </p>
                </div>
                <div class="contentDiv pageDesc">
                    <a href="phpMySQL.php"><h3>PHP MySQL Tutorials Page</h3></a>
                    <p>This page illustrates the sequence of the PHP MySQL Tutorials from W3Schools. This page also provides links to three detailed and interactive PHP MySQL lessons. How to insert data into a database using a form, updating data in a database using a form, and displaying data returned via a query in a database. </p>
                </div>
                <div class="contentDiv pageDesc subPage">
                    <a href="phpFormDB.php"><h3>Using a Form to Insert Data into a Database Tutorial Page</h3></a>
                    <p>This page illustrates how to incorporate an input form onto a PHP page that allows the user to enter data into the database. This form DOES utilize MySQL and connects to a database. Click to learn more about the steps required to successfully connect a PHP form to a database and interact with a pre-built example form.  </p>
                </div>
                <div class="contentDiv pageDesc subPage">
                    <a href="updatingDB.php"><h3>Using a Form to Update a Database Tutorial Page</h3></a>
                    <p>This page illustrates how to use a form to update information within a database. Click to learn more about the steps required to successfully update a database using a PHP form.  </p>
                </div>
                <div class="contentDiv pageDesc subPage">
                    <a href="returnedQuery.php"><h3>Displaying Data Returned from Queries in a Database Tutorial Page</h3></a>
                    <p>This page illustrates how to display data that has been returned from a query in a Table within a database. Click to learn more about the steps required to successfully display data returned from the database via PHP. </p>
                </div>
                <div class="contentDiv pageDesc">
                    <a href="dataVisualization.php"><h3>Data Visualization Tutorial Page</h3></a>
                    <p>This page illustrates how to generate three types of dynamic graphs using data drawn from a database. There will be examples of and instructions for the following charts: Pie Chart, Column Chart, and Spider/Radar Chart. </p>
                </div>
            </div>
        </main>
        <footer>
            <p>Group 4: Madeline Lucas, Dillon Barnhardt, Gerome Vergara</p>
            <p>Dr. John Gerdes</p>
            <p><a href="#top">To Top</a></p>
        </footer>
    </body>
</html>