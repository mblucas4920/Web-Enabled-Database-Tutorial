<!DOCTYPE html>
<html lang="en">
<head>
    <title>Displaying Data Returned from a Query in a Database</title>
    <link rel="stylesheet" href="css\layoutStyle.css">
</head>
<body id="returnedQuery-page" class="lesson-page">
    <nav>
    <div id="logo">
        <img src="imgs/PHP-MySQL-Logo_W_Group4.png" alt="Website Logo">
    </div>
    <div class="navTab">
      <a href="index.php">Home</a>
    </div>
    <div class="navTab">
      <a href="phpForm.php">PHP Form Tutorial</a>
    </div>
    <div class="navTab">
      <a href="phpMySQL.php">PHP MySQL Tutorials</a>
    </div>
    <div class="navTab subTab">
      <a href="phpFormDB.php">Inserting Data into a Database Using a Form</a>
    </div>
    <div class="navTab subTab">
      <a href="updatingDB.php">Updating Data in a Database Using a Form</a>
    </div>
    <div class="navTab subTab">
      <a href="returnedQuery.php" id="active">Displaying Data Returned via a Query in a Database</a>
    </div>
    <div class="navTab">
      <a href="dataVisualization.php">Data Visualization</a>
    </div>
  </nav>

    <header>
        <h1>Displaying Data Returned from a Query in a Database</h1>
    </header>

    <main>
        <div id="mainDiv" class="flexColumn">
            <h2>Lesson: Querying Data in PHP and MySQL</h2>
            <p>This tutorial demonstrates how to use PHP and SQL to retrieve, filter, and summarize data from the <strong>survey_responses</strong> table. Use the dropdown below to explore different examples.</p>
            <div id="sampleData">
                <h3>Click the buttons below to build the websites database and insert sample data into the rows.</h3>
                <div>
                    <a class="button" href="CreateNEWDB.php">Generate survey_responses</a>
                    <a class="button" href="InsertData-Survey.php">Generate Sample Data</a>
                </div>
            </div>
            <!-- Dropdown for query selection -->
            <form method="get">
                <label for="querySelect"><strong>Choose a query example:</strong></label>
                <select name="query" id="querySelect" onchange="this.form.submit()">
                    <option value="">-- Select a Query --</option>
                    <option value="1" <?php if(isset($_GET['query']) && $_GET['query']=='1') echo 'selected'; ?>>1. Sort by Comfort with PHP (High to Low)</option>
                    <option value="2" <?php if(isset($_GET['query']) && $_GET['query']=='2') echo 'selected'; ?>>2. Students Who Prefer Coffee</option>
                    <option value="3" <?php if(isset($_GET['query']) && $_GET['query']=='3') echo 'selected'; ?>>3. Average Skill Scores</option>
                    <option value="4" <?php if(isset($_GET['query']) && $_GET['query']=='4') echo 'selected'; ?>>4. Students with Focus Skill ≥ 7</option>
                    <option value="5" <?php if(isset($_GET['query']) && $_GET['query']=='5') echo 'selected'; ?>>5. Most Common Favorite Beverage</option>
                    <option value="6" <?php if(isset($_GET['query']) && $_GET['query']=='6') echo 'selected'; ?>>6. Top 5 Students by Time Management</option>
                    <option value="7" <?php if(isset($_GET['query']) && $_GET['query']=='7') echo 'selected'; ?>>7. Average Comfort with PHP by Beverage</option>
                    <option value="8" <?php if(isset($_GET['query']) && $_GET['query']=='8') echo 'selected'; ?>>8. Students with Equal Focus and Notes Skills</option>
                </select>
            </form>
            <?php
                // Database connection
                $servername = "localhost";
                $username = "myusername";
                $password = "myPassword";
                $dbname = "surveydb";

                $conn = new mysqli($servername, $username, $password, $dbname);
                if ($conn->connect_error) {
                    die("<p>Connection failed: " . $conn->connect_error . "</p>");
                }

                if (isset($_GET['query']) && $_GET['query'] !== "") {
                    $queryNum = $_GET['query'];

                    switch ($queryNum) {
                        case "1":
                            echo "<h3>1. All Responses Sorted by Comfort with PHP (High → Low)</h3>";
                            echo "<p>This query shows all students, sorted from the most comfortable with PHP to the least. Useful to see who is most confident.</p>";
                            $sql = "SELECT name, comfort_php, favorite_beverage FROM survey_responses ORDER BY comfort_php DESC";
                            break;

                        case "2":
                            echo "<h3>2. Students Who Prefer Coffee</h3>";
                            echo "<p>This query filters students whose favorite beverage is Coffee. It's an example of using a WHERE clause.</p>";
                            $sql = "SELECT name, favorite_beverage, skill_focus FROM survey_responses WHERE favorite_beverage = 'Coffee'";
                            break;

                        case "3":
                            echo "<h3>3. Average Skill Scores</h3>";
                            echo "<p>This query calculates the average scores of all students for Time, Focus, and Notes skills using the AVG() function.</p>";
                            $sql = "SELECT ROUND(AVG(skill_time),2) AS avg_time, ROUND(AVG(skill_focus),2) AS avg_focus, ROUND(AVG(skill_notes),2) AS avg_notes FROM survey_responses";
                            break;

                        case "4":
                            echo "<h3>4. Students with Focus Skill ≥ 7</h3>";
                            echo "<p>This query filters students who have a high Focus skill (7 or more), showing who excels in focus.</p>";
                            $sql = "SELECT name, skill_focus, comfort_php FROM survey_responses WHERE skill_focus >= 7 ORDER BY skill_focus DESC";
                            break;

                        case "5":
                            echo "<h3>5. Most Common Favorite Beverage</h3>";
                            echo "<p>This query groups students by their favorite beverage, counts them, and shows the beverage with the most students.</p>";
                            $sql = "SELECT favorite_beverage, COUNT(*) AS total FROM survey_responses GROUP BY favorite_beverage ORDER BY total DESC LIMIT 1";
                            break;

                        case "6":
                            echo "<h3>6. Top 5 Students by Time Management Skills</h3>";
                            echo "<p>This query selects the top 5 students based on their Time Management skill (skill_time). Useful to identify strong time managers.</p>";
                            $sql = "SELECT name, skill_time FROM survey_responses ORDER BY skill_time DESC LIMIT 5";
                            break;

                        case "7":
                            echo "<h3>7. Average Comfort with PHP by Beverage</h3>";
                            echo "<p>This query calculates the average PHP comfort for each favorite beverage using GROUP BY. Good for analyzing trends by groups.</p>";
                            $sql = "SELECT favorite_beverage, ROUND(AVG(comfort_php),2) AS avg_comfort FROM survey_responses GROUP BY favorite_beverage ORDER BY avg_comfort DESC";
                            break;

                        case "8":
                            echo "<h3>8. Students with Equal Focus and Notes Skills</h3>";
                            echo "<p>This query finds students whose Focus skill equals their Notes skill. It's an example of comparing multiple columns in WHERE.</p>";
                            $sql = "SELECT name, skill_focus, skill_notes FROM survey_responses WHERE skill_focus = skill_notes";
                            break;
                    }

                    $result = $conn->query($sql);

                    if ($result && $result->num_rows > 0) {
                        echo "<table border='1'><tr>";

                        // Print table headers dynamically
                        while ($fieldinfo = $result->fetch_field()) {
                            echo "<th>{$fieldinfo->name}</th>";
                        }
                        echo "</tr>";

                        // Print rows
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            foreach ($row as $value) {
                                echo "<td>{$value}</td>";
                            }
                            echo "</tr>";
                        }
                        echo "</table>";
                    } else {
                        echo "<p>No results found.</p>";
                    }
                }

                $conn->close();
            ?>
        </div>
        
        <div class="lessons-nav flexColumn">
            <h3>More PHP MySQL Lessons</h3>
            <div>
                <a class="lessonLink" href="phpFormDB.php">Lesson: Using a Form to Insert Data into a Database</a>
                <a class="lessonLink" href="updatingDB.php">Lesson: Using a Form to Update Data in a Database</a>
            </div>
        </div>
    </main>
    <footer>
        <p>Group 4: Madeline Lucas, Dillon Barnhardt, Gerome Vergara</p>
        <p>Dr. John Gerdes</p>
        <p><a href="#top">To Top</a></p>
    </footer>
</body>
</html>