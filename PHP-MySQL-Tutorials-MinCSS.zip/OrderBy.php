<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Select Data Ordered by Lastname</title>
  <link rel="stylesheet" href="css\layoutStyle.css">
</head>
<body id="W3Schools-page">
<nav>
    <div id="logo">
      <img src="imgs/PHP-MySQL-Logo_W_Group4.png" alt="Website Logo">
    </div>
    <div class="navTab">
      <a href="index.php">Home</a>
    </div>
    <div class="navTab">
      <a href="phpForm.php">PHP Form Tutorial</a>
    </div>
    <div class="navTab">
      <a href="phpMySQL.php" id="active">PHP MySQL Tutorials</a>
    </div>
    <div class="navTab subTab">
      <a href="phpFormDB.php">Inserting Data into a Database Using a Form</a>
    </div>
    <div class="navTab subTab">
      <a href="updatingDB.php">Updating Data in a Database Using a Form</a>
    </div>
    <div class="navTab subTab">
      <a href="returnedQuery.php">Displaying Data Returned via a Query in a Database</a>
    </div>
    <div class="navTab">
      <a href="dataVisualization.php">Data Visualization</a>
    </div>
  </nav>
  <header>
    <h1>Select Data Ordered by Lastname</h1>
    <a href="https://www.w3schools.com/php/php_mysql_select_orderby.asp" class="headerLink">W3Schools Link</a>
  </header>
  <main class="W3Schools-main">
    <h2>Step 1: Understanding This Page</h2>
    <p>This page demonstrates how to select and display all records from the <strong>MyGuests</strong> table ordered by the <strong>lastname</strong> column using <strong>MySQLi Procedural</strong>.</p>

    <h2>Step 2: PHP Output</h2>
    <p>Below is the live output of the records sorted alphabetically by lastname:</p>
    <p>
      <?php
        $servername = "localhost";
        $username = "myusername";
        $password = "myPassword";
        $dbname = "myDB";

        // Create connection
        $conn = mysqli_connect($servername, $username, $password, $dbname);

        // Check connection
        if (!$conn) {
          die("Connection failed: " . mysqli_connect_error());
        }

        // SELECT query with ORDER BY
        $sql = "SELECT id, firstname, lastname FROM MyGuests ORDER BY lastname";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
          while($row = mysqli_fetch_assoc($result)) {
            echo "id: " . $row["id"] . " - Name: " . $row["firstname"] . " " . $row["lastname"] . "<br>";
          }
        } else {
          echo "0 results";
        }

        mysqli_close($conn);
      ?>
    </p>

    <h2>Step 3: How the Code Works</h2>
    <p>The code connects to the database, executes a <strong>SELECT</strong> query with an <strong>ORDER BY</strong> clause to sort the results by <strong>lastname</strong>, 
    and displays each record. If no records exist, it displays "0 results".</p>

    <pre>
      &lt;?php
      $conn = mysqli_connect($servername, $username, $password, $dbname);

      if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
      }

      $sql = "SELECT id, firstname, lastname FROM MyGuests ORDER BY lastname";
      $result = mysqli_query($conn, $sql);

      if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
          echo "id: " . $row["id"] . " - Name: " . $row["firstname"] . " " . $row["lastname"] . "&lt;br&gt;";
        }
      } else {
        echo "0 results";
      }

      mysqli_close($conn);
      ?&gt;
    </pre>

    <h2>Return to the Menu</h2>
    <a href="phpMySQL.php">Return to Menu</a>
  </main>
  <footer>
    <p>Group 4: Madeline Lucas, Dillon Barnhardt, Gerome Vergara</p>
    <p>Dr. John Gerdes</p>
    <p><a href="#top">To Top</a></p>
  </footer>
</body>
</html>