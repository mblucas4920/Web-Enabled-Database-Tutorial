function showOutput(){
    var output = document.getElementByClass("hidden-div");
    if (output.style.display == "none"){
        output.style.display = "block";
    } else {
        output.style.display = "none";
    }
}