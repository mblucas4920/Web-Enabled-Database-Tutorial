<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Connect - PDO</title>
  <link rel="stylesheet" href="css\layoutStyle.css">
</head>
<body id="W3Schools-page">
  <nav>
      <div id="logo">
          <img src="imgs/PHP-MySQL-Logo_W_Group4.png" alt="Website Logo">
      </div>
      <div class="navTab">
        <a href="index.php">Home</a>
      </div>
      <div class="navTab">
        <a href="phpForm.php">PHP Form Tutorial</a>
      </div>
      <div class="navTab">
        <a href="phpMySQL.php" id="active">PHP MySQL Tutorials</a>
      </div>
      <div class="navTab subTab">
        <a href="phpFormDB.php">Inserting Data into a Database Using a Form</a>
      </div>
      <div class="navTab subTab">
        <a href="updatingDB.php">Updating Data in a Database Using a Form</a>
      </div>
      <div class="navTab subTab">
        <a href="returnedQuery.php">Displaying Data Returned via a Query in a Database</a>
      </div>
      <div class="navTab">
        <a href="dataVisualization.php">Data Visualization</a>
      </div>
  </nav>
  <header>
    <h1>Connect - PDO</h1>
    <a href="https://www.w3schools.com/php/php_mysql_connect.asp" class="headerLink">W3Schools Link</a>
  </header>
  <main class="W3Schools-main">
    <h2>Step 1: Understanding This Page</h2>
    <p>This page tests whether your PHP setup can connect to a MySQL database using <strong>PDO (PHP Data Objects)</strong>. 
    PDO provides a flexible, secure, and object-oriented way to interact with databases.</p>

    <h2>Step 2: PHP Output</h2>
    <p>Below is the result of the PHP connection test:</p>
    <p>
      <?php
        $servername = "localhost";
        $username = "myusername";
        $password = "myPassword";

        // Create connection
        try {
          $conn = new PDO("mysql:host=$servername;dbname=myDB", $username, $password);
          // Set the PDO error mode to exception
          $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
          echo "Connected successfully";
        } catch(PDOException $e) {
          echo "Connection failed: " . $e->getMessage();
        }
      ?>
    </p>

    <h2>Step 3: How the Code Works</h2>
    <p>The PHP code used on this page looks like this:</p>
    <pre>
      &lt;?php
        $servername = "localhost";
        $username = "myusername";
        $password = "myPassword";

        try {
          $conn = new PDO("mysql:host=$servername;dbname=myDB", $username, $password);
          $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
          echo "Connected successfully";
        } catch(PDOException $e) {
          echo "Connection failed: " . $e->getMessage();
        }
      ?&gt;
    </pre>
    <p>This code connects PHP to a MySQL database using PDO. 
    The <strong>try...catch</strong> block ensures that if a connection error occurs, 
    it’s caught and displayed instead of stopping the script completely.</p>

    <h2>Return to the Menu</h2>
    <p>Once you’ve confirmed the connection works, return to your main site menu below.</p>
    <a href="phpMySQL.php">Return to Menu</a>
  </main>
  <footer>
    <p>Group 4: Madeline Lucas, Dillon Barnhardt, Gerome Vergara</p>
    <p>Dr. John Gerdes</p>
    <p><a href="#top">To Top</a></p>
  </footer>
</body>
</html>
