<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Create Database</title>
  <link rel="stylesheet" href="css\layoutStyle.css">
</head>
<body id="W3Schools-page">
  <nav>
    <div id="logo">
      <img src="imgs/PHP-MySQL-Logo_W_Group4.png" alt="Website Logo">
    </div>
    <div class="navTab">
      <a href="index.php">Home</a>
    </div>
    <div class="navTab">
      <a href="phpForm.php">PHP Form Tutorial</a>
    </div>
    <div class="navTab">
      <a href="phpMySQL.php" id="active">PHP MySQL Tutorials</a>
    </div>
    <div class="navTab subTab">
      <a href="phpFormDB.php">Inserting Data into a Database Using a Form</a>
    </div>
    <div class="navTab subTab">
      <a href="updatingDB.php">Updating Data in a Database Using a Form</a>
    </div>
    <div class="navTab subTab">
      <a href="returnedQuery.php">Displaying Data Returned via a Query in a Database</a>
    </div>
    <div class="navTab">
      <a href="dataVisualization.php">Data Visualization</a>
    </div>
  </nav>
  <header>
    <h1>Create Database</h1>
    <a href="https://www.w3schools.com/php/php_mysql_create.asp" class="headerLink">W3Schools Link</a>
  </header>
  <main class="W3Schools-main">
    <h2>Step 1: Understanding This Page</h2>
    <p>This page demonstrates how to create new databases using PHP and the MySQLi <strong>object-oriented</strong> method. 
    It attempts to create two databases named <strong>myDB</strong> and <strong>myPDO</strong>.</p>
    <p><strong>Note:</strong> You can only run this command once successfully. 
    If the databases already exist, trying to create them again will result in an error.</p>

    <h2>Step 2: PHP Output</h2>
    <p>Below is the live PHP result from attempting to create the databases:</p>
    <p>
      <?php
        $servername = "localhost";
        $username = "myusername";
        $password = "myPassword";

        // Create connection
        $conn = new mysqli($servername, $username, $password);

        // Check connection
        if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
        }

        // Create myDB database
        $sql = "CREATE DATABASE myDB";
        if ($conn->query($sql) === TRUE) {
          echo "Database 'myDB' created successfully.<br>";
        } else {
          echo "Error creating 'myDB': " . $conn->error . "<br>";
        }

        // Create myPDO database
        $sql = "CREATE DATABASE myPDO";
        if ($conn->query($sql) === TRUE) {
          echo "Database 'myPDO' created successfully.<br>";
        } else {
          echo "Error creating 'myPDO': " . $conn->error . "<br>";
        }

        $conn->close();
      ?>
    </p>

    <h2>Step 3: How the Code Works</h2>
    <p>The PHP code used on this page looks like this:</p>
    <pre>
      &lt;?php
        $servername = "localhost";
        $username = "myusername";
        $password = "myPassword";

        // Create connection
        $conn = new mysqli($servername, $username, $password);

        // Check connection
        if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
        }

        // Create databases
        $sql = "CREATE DATABASE myDB";
        $conn->query($sql);

        $sql = "CREATE DATABASE myPDO";
        $conn->query($sql);

        $conn->close();
      ?&gt;
    </pre>
    <p>This code connects to the MySQL server and sends SQL commands to create two databases: 
    <strong>myDB</strong> and <strong>myPDO</strong>. If the databases already exist, an error will be displayed instead.</p>

    <h2>Return to the Menu</h2>
    <p>After confirming your databases have been created, return to your main menu below.</p>
    <a href="phpMySQL.php">Return to Menu</a>
  </main>
  <footer>
    <p>Group 4: Madeline Lucas, Dillon Barnhardt, Gerome Vergara</p>
    <p>Dr. John Gerdes</p>
    <p><a href="#top">To Top</a></p>
  </footer>
</body>
</html>