<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Create Survey Database</title>
  <link rel="stylesheet" href="css\layoutStyle.css">
</head>
<body id="entry-page">
<nav>
  <div id="logo">
    <img src="imgs/PHP-MySQL-Logo_W_Group4.png" alt="Website Logo">
  </div>
  <div class="navTab">
    <a href="index.php">Home</a>
  </div>
  <div class="navTab">
    <a href="phpForm.php">PHP Form Tutorial</a>
  </div>
  <div class="navTab">
    <a href="phpMySQL.php" id="active">PHP MySQL Tutorials</a>
  </div>
  <div class="navTab subTab">
    <a href="phpFormDB.php">Inserting Data into a Database Using a Form</a>
  </div>
  <div class="navTab subTab">
    <a href="updatingDB.php">Updating Data in a Database Using a Form</a>
  </div>
  <div class="navTab subTab">
    <a href="returnedQuery.php">Displaying Data Returned via a Query in a Database</a>
  </div>
  <div class="navTab">
    <a href="dataVisualization.php">Data Visualization</a>
  </div>
</nav>
<header>
  <h1>Database Created</h1>
</header>
<main class="flexColumn" id="newDB">
  <p>
    <?php
      $servername = "localhost";
      $username = "myusername"; 
      $password = "myPassword";  
      $dbname = "surveyDB"; 

      // Connect to MySQL server
      $conn = new mysqli($servername, $username, $password);

      // Check connection
      if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
      }

      // Create database
      $sql = "CREATE DATABASE IF NOT EXISTS $dbname";
      if ($conn->query($sql) === TRUE) {
          $conn->select_db($dbname);

          // Create table with 0-9 skill ratings
          $tableSql = "
            CREATE TABLE IF NOT EXISTS survey_responses (
              id INT(11) AUTO_INCREMENT PRIMARY KEY,
              name VARCHAR(100),
              comfort_mysql TINYINT CHECK (comfort_mysql BETWEEN 1 AND 5),
              comfort_php TINYINT CHECK (comfort_php BETWEEN 1 AND 5),
              comfort_html TINYINT CHECK (comfort_html BETWEEN 1 AND 5),
              favorite_beverage ENUM('Coffee','Tea','Soda','Water','Energy Drink'),
              skill_time TINYINT CHECK (skill_time BETWEEN 0 AND 9),
              skill_focus TINYINT CHECK (skill_focus BETWEEN 0 AND 9),
              skill_notes TINYINT CHECK (skill_notes BETWEEN 0 AND 9),
              skill_collab TINYINT CHECK (skill_collab BETWEEN 0 AND 9),
              skill_problem TINYINT CHECK (skill_problem BETWEEN 0 AND 9),
              skill_stress TINYINT CHECK (skill_stress BETWEEN 0 AND 9)
            )";

          if ($conn->query($tableSql) === TRUE) {
              echo "new db was created!";
          } else {
              echo "Error creating table: " . $conn->error;
          }

      } else {
          echo "Error creating database: " . $conn->error;
      }

      $conn->close();
    ?>
  </p>
  <div id="return">
    <a href="returnedQuery.php">Return to previous page</a>
  </div>
</main>
<footer>
  <p>Group 4: Madeline Lucas, Dillon Barnhardt, Gerome Vergara</p>
  <p>Dr. John Gerdes</p>
  <p><a href="#top">To Top</a></p>
</footer>
</body>
</html>
</body>
</html>