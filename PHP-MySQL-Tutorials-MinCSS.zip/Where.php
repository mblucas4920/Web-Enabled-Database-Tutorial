<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>SELECT with WHERE</title>
  <link rel="stylesheet" href="css\layoutStyle.css">
</head>
<body id="W3Schools-page">
<nav>
    <div id="logo">
      <img src="imgs/PHP-MySQL-Logo_W_Group4.png" alt="Website Logo">
    </div>
    <div class="navTab">
      <a href="index.php">Home</a>
    </div>
    <div class="navTab">
      <a href="phpForm.php">PHP Form Tutorial</a>
    </div>
    <div class="navTab">
      <a href="phpMySQL.php" id="active">PHP MySQL Tutorials</a>
    </div>
    <div class="navTab subTab">
      <a href="phpFormDB.php">Inserting Data into a Database Using a Form</a>
    </div>
    <div class="navTab subTab">
      <a href="updatingDB.php">Updating Data in a Database Using a Form</a>
    </div>
    <div class="navTab subTab">
      <a href="returnedQuery.php">Displaying Data Returned via a Query in a Database</a>
    </div>
    <div class="navTab">
      <a href="dataVisualization.php">Data Visualization</a>
    </div>
  </nav>
  <header>
    <h1>SELECT with WHERE</h1>
    <a href="https://www.w3schools.com/php/php_mysql_select_where.asp" class="headerLink">W3Schools Link</a>
  </header>

  <main class="W3Schools-main">
    <h2>Step 1: Understanding This Page</h2>
    <p>This page demonstrates how to retrieve specific rows from a table using a <strong>WHERE</strong> clause in SQL. 
    It selects all guests from the <strong>MyGuests</strong> table whose last name is <strong>Doe</strong>.</p>

    <h2>Step 2: PHP Output</h2>
    <p>Below is the live output from the SQL query:</p>
    <p>
      <?php
        $servername = "localhost";
        $username = "myusername";
        $password = "myPassword";
        $dbname = "myDB";

        // Create connection
        $conn = mysqli_connect($servername, $username, $password, $dbname);

        // Check connection
        if (!$conn) {
          die("Connection failed: " . mysqli_connect_error());
        }

        // SQL query using WHERE clause
        $sql = "SELECT id, firstname, lastname FROM MyGuests WHERE lastname='Doe'";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
          // Output data of each row
          while ($row = mysqli_fetch_assoc($result)) {
            echo "ID: " . $row["id"] . " - Name: " . $row["firstname"] . " " . $row["lastname"] . "<br>";
          }
        } else {
          echo "0 results";
        }

        mysqli_close($conn);
      ?>
    </p>

    <h2>Step 3: How the Code Works</h2>
    <p>The code connects to the database, executes a SELECT query with a WHERE clause, and displays the results if any match the condition.</p>
    <pre>
      &lt;?php
        $servername = "localhost";
        $username = "myusername";
        $password = "myPassword";
        $dbname = "myDB";

        $conn = mysqli_connect($servername, $username, $password, $dbname);

        if (!$conn) {
          die("Connection failed: " . mysqli_connect_error());
        }

        $sql = "SELECT id, firstname, lastname FROM MyGuests WHERE lastname='Doe'";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
          while ($row = mysqli_fetch_assoc($result)) {
            echo "ID: " . $row["id"] . " - Name: " . $row["firstname"] . " " . $row["lastname"] . "&lt;br&gt;";
          }
        } else {
          echo "0 results";
        }

        mysqli_close($conn);
      ?&gt;
    </pre>

    <h2>Return to the Menu</h2>
    <a href="phpMySQL.php">Return to Menu</a>
  </main>
  <footer>
    <p>Group 4: Madeline Lucas, Dillon Barnhardt, Gerome Vergara</p>
    <p>Dr. John Gerdes</p>
    <p><a href="#top">To Top</a></p>
  </footer>
</body>
</html>