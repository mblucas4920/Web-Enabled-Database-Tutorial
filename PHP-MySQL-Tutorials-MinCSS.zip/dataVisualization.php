<?php
// dataVisualization.php - wrapper to show the three dynamic pChart graphs
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PHP MySQL Tutorial Website - Data Visualization</title>
    <link rel="stylesheet" href="css\layoutStyle.css">
    <style>
      /* Small additions so embedded charts display nicely inside current layout */
      .charts-grid { display:flex; flex-wrap:wrap; gap:20px; margin-top:10px; }
      .chart-container { background:#fff; padding:12px; border:1px solid #ddd; border-radius:6px; width:100%; box-sizing:border-box; }
      @media(min-width:1000px){ .chart-container { width:48%; } }
      .chart-container img { max-width:100%; height:auto; display:block; margin:6px 0; border:1px solid #eee; }
      .chart-caption { font-size:0.95rem; color:#444; margin-bottom:6px; }
      .dynamic-note { font-style:italic; color:#333; margin-top:14px; }
    </style>
</head>
<body id="dataVizPage">

    <nav>
        <div id="logo">
            <img src="imgs/PHP-MySQL-Logo_W_Group4.png" alt="Website Logo">
        </div>
        <div class="navTab">
            <a href="index.php">Home</a>
        </div>
        <div class="navTab">
            <a href="phpForm.php">PHP Form Tutorial</a>
        </div>
        <div class="navTab">
            <a href="phpMySQL.php">PHP MySQL Tutorials</a>
        </div>
        <div class="navTab subTab">
            <a href="phpFormDB.php">Inserting Data into a Database Using a Form</a>
        </div>
        <div class="navTab subTab">
            <a href="updatingDB.php">Updating Data in a Database Using a Form</a>
        </div>
        <div class="navTab subTab">
            <a href="returnedQuery.php">Displaying Data Returned via a Query in a Database</a>
        </div>
        <div class="navTab">
            <a href="dataVisualization.php" id="active">Data Visualization</a>
        </div>
    </nav>

    <header>
        <h1>Learning Module: Data Visualization with PHP and MySQL</h1>
    </header>

    <main class="contentDiv">
        <section>
            <h2>Overview</h2>
            <p>
                This page demonstrates how to use PHP to retrieve data from a MySQL database 
                and visualize it using an external PHP graphing API. For this project, 
                we will use <strong>pChart</strong>, a free and flexible library that can create
                various graph types such as pie charts, bar charts, and radar charts.
            </p>
            <p>
                The goal of this section is to illustrate how to dynamically generate graphs 
                that update automatically as new data is added to the database.
            </p>
        </section>

        <section>
            <h2>Learning Objectives</h2>
            <ul>
                <li>Connect to a MySQL database and retrieve data for visualization.</li>
                <li>Integrate the pChart API into a PHP project.</li>
                <li>Create dynamic graph types such as Pie, Column (Bar), and Spider (Radar) charts.</li>
                <li>Demonstrate how visual data can reflect real-time changes in a database.</li>
            </ul>
        </section>

        <section>
            <h2>Step-by-Step Instructions</h2>
            <ol>
                <li>Download and install the <strong>pChart</strong> library into your project directory.</li>
                <li>Create a connection to your database (e.g., <code>mydb</code>) via <code>Connect-PDO.php</code>.</li>
                <li>Use SQL queries to retrieve relevant data such as user responses or counts.</li>
                <li>Use pChart to generate charts dynamically from these results (server-side PNGs).</li>
                <li>Embed the generated images into a web page using &lt;img src="...php"&gt; so they update automatically.</li>
            </ol>
        </section>

        <section>
            <h2>Demonstration Area</h2>
            <p>The charts below are generated dynamically using data from the <strong>myguests</strong> table in your database.</p>

            <div class="charts-grid">
                <div class="chart-container">
                    <h3>Chart 1: Pie Chart</h3>
                    <p class="chart-caption">(Distribution of guests by first name — dynamic)</p>
                    <img src="data_pie.php" alt="Pie Chart - Guests by First Name">
                </div>

                <div class="chart-container">
                    <h3>Chart 2: Column Chart</h3>
                    <p class="chart-caption">(Registrations per date — dynamic)</p>
                    <img src="data_column.php" alt="Column Chart - Registrations per Date">
                </div>

                <div class="chart-container">
                    <h3>Chart 3: Spider (Radar) Chart</h3>
                    <p class="chart-caption">(Derived metrics per guest — dynamic)</p>
                    <img src="data_radar.php" alt="Radar Chart - Derived Metrics per Guest">
                </div>
            </div>

            <p class="dynamic-note">
              Note: each of the charts above is generated on-the-fly by PHP using pChart and the current database contents.
              Refresh this page after you add or update records in the <strong>myguests</strong> table to see the charts change.
            </p>
        </section>

        <section>
            <h2>Documentation Notes</h2>
            <p>
                Once the charts are implemented, this section will also include a brief explanation 
                of how each API function from pChart is used. For example:
            </p>
            <ul>
                <li><code>pData()</code> – creates and structures your dataset.</li>
                <li><code>pImage()</code> – initializes the chart canvas.</li>
                <li><code>drawBarChart()</code>, <code>drawPieGraph()</code>, <code>drawRadar()</code> – generate different chart types.</li>
                <li><code>Render()</code> – outputs the final image to the page.</li>
            </ul>
        </section>
    </main>

    <footer>
        <p>Group 4: Madeline Lucas, Dillon Barnhardt, Gerome Vergara</p>
        <p>Dr. John Gerdes</p>
        <p><a href="#top">To Top</a></p>
    </footer>

</body>
</html>
